//! Speed measurement system.

/// TODO: Place holder for speed measurement.
fn main() {
    println!("Hello, world!");
}
